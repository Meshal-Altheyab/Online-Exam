using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OnlineExam.Models;

namespace OnlineExam.Controllers;

/// <summary>
/// Handles display and editing of the authenticated user's profile. Users
/// may update their display name, university and profile picture. Password
/// updates are delegated to the built‑in Identity management pages.
/// </summary>
[Authorize]
public class ProfileController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly IWebHostEnvironment _env;

    public ProfileController(UserManager<ApplicationUser> userManager,
                             SignInManager<ApplicationUser> signInManager,
                             IWebHostEnvironment env)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _env = env;
    }

    /// <summary>
    /// Displays the current user's profile information.
    /// </summary>
    public async Task<IActionResult> Index()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null)
        {
            return NotFound();
        }
        return View(user);
    }

    /// <summary>
    /// GET: Display form to edit the user's name and university.
    /// </summary>
    public async Task<IActionResult> Edit()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null)
        {
            return NotFound();
        }
        return View(user);
    }

    /// <summary>
    /// POST: Persist updates to the user's profile. Only name and
    /// university can be edited here. Profile image updates are handled
    /// separately.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(ApplicationUser model)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null)
        {
            return NotFound();
        }
        if (ModelState.IsValid)
        {
            user.Name = model.Name;
            user.University = model.University;
            await _userManager.UpdateAsync(user);
            // Refresh the sign‑in cookie to reflect the updated claims
            await _signInManager.RefreshSignInAsync(user);
            TempData["StatusMessage"] = "Profile updated successfully.";
            return RedirectToAction(nameof(Index));
        }
        return View(model);
    }

    /// <summary>
    /// GET: Display form for uploading a new profile image.
    /// </summary>
    public IActionResult UploadImage()
    {
        return View();
    }

    /// <summary>
    /// POST: Process profile image uploads. Only JPEG, PNG and GIF files
    /// smaller than 2MB are permitted. The uploaded file is saved to
    /// wwwroot/images/profiles and the user's ProfileImagePath is updated.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UploadImage(IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            ModelState.AddModelError(string.Empty, "Please select an image file.");
            return View();
        }
        // Validate extension
        var permittedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif" };
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (string.IsNullOrEmpty(ext) || !permittedExtensions.Contains(ext))
        {
            ModelState.AddModelError(string.Empty, "Invalid image format. Only JPG, PNG and GIF are allowed.");
            return View();
        }
        // Limit file size to 2MB
        if (file.Length > 2 * 1024 * 1024)
        {
            ModelState.AddModelError(string.Empty, "Image size cannot exceed 2MB.");
            return View();
        }
        var user = await _userManager.GetUserAsync(User);
        if (user == null)
        {
            return NotFound();
        }
        var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "profiles");
        Directory.CreateDirectory(uploadsFolder);
        var uniqueFileName = $"{Guid.NewGuid()}{ext}";
        var filePath = Path.Combine(uploadsFolder, uniqueFileName);
        using (var fileStream = new FileStream(filePath, FileMode.Create))
        {
            await file.CopyToAsync(fileStream);
        }
        // Delete old image if exists
        if (!string.IsNullOrEmpty(user.ProfileImagePath))
        {
            var oldPath = user.ProfileImagePath.TrimStart('/', '\\');
            var absoluteOld = Path.Combine(_env.WebRootPath, oldPath);
            if (System.IO.File.Exists(absoluteOld))
            {
                System.IO.File.Delete(absoluteOld);
            }
        }
        user.ProfileImagePath = $"/images/profiles/{uniqueFileName}";
        await _userManager.UpdateAsync(user);
        await _signInManager.RefreshSignInAsync(user);
        TempData["StatusMessage"] = "Profile image updated successfully.";
        return RedirectToAction(nameof(Index));
    }
}