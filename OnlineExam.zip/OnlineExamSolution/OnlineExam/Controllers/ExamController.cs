using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExam.Data;
using OnlineExam.Models;

namespace OnlineExam.Controllers;

/// <summary>
/// Enables educators and administrators to create, edit and delete exams.
/// Exams have a title, description, subject, difficulty level, start/end
/// times and a duration in minutes. Only the educator who created an exam
/// or an administrator may modify it.
/// </summary>
[Authorize(Roles = "Educator,Admin")]
public class ExamController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public ExamController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // GET: /Exam
    public async Task<IActionResult> Index()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        IQueryable<Exam> examsQuery = _context.Exams.Include(e => e.Creator);
        // Educators see only their exams; admins see all
        if (!User.IsInRole("Admin"))
        {
            examsQuery = examsQuery.Where(e => e.CreatorId == user.Id);
        }
        var exams = await examsQuery.OrderByDescending(e => e.StartTime).ToListAsync();
        return View(exams);
    }

    // GET: /Exam/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: /Exam/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Title,Description,Subject,Difficulty,StartTime,EndTime,DurationMinutes")] Exam exam)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        if (ModelState.IsValid)
        {
            exam.CreatorId = user.Id;
            _context.Add(exam);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(exam);
    }

    // GET: /Exam/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();
        var exam = await _context.Exams.FindAsync(id);
        if (exam == null) return NotFound();
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        if (!User.IsInRole("Admin") && exam.CreatorId != user.Id)
        {
            return Forbid();
        }
        return View(exam);
    }

    // POST: /Exam/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Description,Subject,Difficulty,StartTime,EndTime,DurationMinutes")] Exam exam)
    {
        if (id != exam.Id) return NotFound();
        var existing = await _context.Exams.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
        if (existing == null) return NotFound();
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        if (!User.IsInRole("Admin") && existing.CreatorId != user.Id)
        {
            return Forbid();
        }
        if (ModelState.IsValid)
        {
            try
            {
                exam.CreatorId = existing.CreatorId; // preserve creator
                _context.Update(exam);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Exams.Any(e => e.Id == exam.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        return View(exam);
    }

    // GET: /Exam/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();
        var exam = await _context.Exams.Include(e => e.Creator).FirstOrDefaultAsync(m => m.Id == id);
        if (exam == null) return NotFound();
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        if (!User.IsInRole("Admin") && exam.CreatorId != user.Id)
        {
            return Forbid();
        }
        return View(exam);
    }

    // POST: /Exam/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var exam = await _context.Exams.FindAsync(id);
        if (exam == null) return NotFound();

        // (Optional) enforce that only Admin or the creator can delete
        // var user = await _userManager.GetUserAsync(User);
        // if (!User.IsInRole("Admin") && exam.CreatorId != user!.Id) return Forbid();

        // 1) Delete student attempts for this exam (their answers will cascade from StudentExam)
        var studentExams = await _context.StudentExams
            .Where(se => se.ExamId == id)
            .ToListAsync();
        _context.StudentExams.RemoveRange(studentExams);

        // 2) Delete questions for this exam (Options will cascade from Question)
        var questions = await _context.Questions
            .Where(q => q.ExamId == id)
            .ToListAsync();
        _context.Questions.RemoveRange(questions);

        // 3) Now delete the exam itself
        _context.Exams.Remove(exam);

        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }


    // GET: /Exam/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();
        var exam = await _context.Exams
            .Include(e => e.Creator)
            .Include(e => e.Questions)
            .ThenInclude(q => q.Options)
            .FirstOrDefaultAsync(m => m.Id == id);
        if (exam == null) return NotFound();
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        if (!User.IsInRole("Admin") && exam.CreatorId != user.Id)
        {
            return Forbid();
        }
        return View(exam);
    }
}