using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExam.Data;
using OnlineExam.Models;

namespace OnlineExam.Controllers;

[Authorize(Roles = "Student")]
public class StudentExamController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public StudentExamController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // GET: /StudentExam/Available
    public async Task<IActionResult> Available()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();

        var now = DateTime.Now;

        var exams = await _context.Exams
            .Where(e => e.StartTime <= now && e.EndTime >= now)
            .OrderBy(e => e.StartTime)
            .ToListAsync();

        var myExamIds = await _context.StudentExams
            .Where(se => se.StudentId == user.Id)
            .Select(se => se.ExamId)
            .ToListAsync();

        var available = exams.Where(e => !myExamIds.Contains(e.Id)).ToList();
        return View(available);
    }

    // GET: /StudentExam/Start/5
    public async Task<IActionResult> Start(int examId)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();

        var exam = await _context.Exams
            .Include(e => e.Questions)
                .ThenInclude(q => q.Options)
            .FirstOrDefaultAsync(e => e.Id == examId);

        if (exam == null) return NotFound();

        var now = DateTime.Now;
        if (now < exam.StartTime || now > exam.EndTime)
        {
            TempData["StatusMessage"] = "This exam is not currently available.";
            return RedirectToAction(nameof(Available));
        }

        // Prevent starting an empty exam
        if (exam.Questions == null || !exam.Questions.Any())
        {
            TempData["StatusMessage"] = "This exam has no questions yet.";
            return RedirectToAction(nameof(Available));
        }

        // Reuse existing attempt if present
        var existing = await _context.StudentExams
            .Include(se => se.Answers)
            .FirstOrDefaultAsync(se => se.ExamId == examId && se.StudentId == user.Id);

        if (existing != null)
        {
            return existing.IsCompleted
                ? RedirectToAction(nameof(Result), new { studentExamId = existing.Id })
                : RedirectToAction(nameof(Take), new { studentExamId = existing.Id });
        }

        var studentExam = new StudentExam
        {
            ExamId = examId,
            StudentId = user.Id,
            StartTime = now,
            EndTime = now.AddMinutes(exam.DurationMinutes),
            IsCompleted = false,
            Score = 0,
            IsPassed = false
        };

        _context.StudentExams.Add(studentExam);
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(Take), new { studentExamId = studentExam.Id });
    }

    // GET: /StudentExam/Take/5
    public async Task<IActionResult> Take(int studentExamId)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();

        var studentExam = await _context.StudentExams
            .Include(se => se.Exam)
                .ThenInclude(e => e.Questions)
                    .ThenInclude(q => q.Options)
            .FirstOrDefaultAsync(se => se.Id == studentExamId && se.StudentId == user.Id);

        if (studentExam == null) return NotFound();

        if (studentExam.IsCompleted)
            return RedirectToAction(nameof(Result), new { studentExamId });

        var now = DateTime.Now;
        var remaining = (studentExam.EndTime - now).TotalSeconds;
        if (remaining <= 0)
            return await AutoSubmit(studentExam);

        ViewBag.RemainingSeconds = remaining;
        return View(studentExam);
    }

    // POST: /StudentExam/Submit
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Submit(int studentExamId)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();

        var studentExam = await _context.StudentExams
            .Include(se => se.Exam)
                .ThenInclude(e => e.Questions)
                    .ThenInclude(q => q.Options)
            .Include(se => se.Answers)
            .FirstOrDefaultAsync(se => se.Id == studentExamId && se.StudentId == user.Id);

        if (studentExam == null) return NotFound();
        if (studentExam.IsCompleted)
            return RedirectToAction(nameof(Result), new { studentExamId });

        var exam = studentExam.Exam!;
        double totalCorrect = 0;

        // Read answers directly from Request.Form (matches name="q_{id}" in the view)
        var form = HttpContext.Request.Form;

        foreach (var question in exam.Questions)
        {
            var key = $"q_{question.Id}";
            var value = form[key].FirstOrDefault();

            var answerRecord = new StudentAnswer
            {
                StudentExamId = studentExamId,
                QuestionId = question.Id
            };

            bool isCorrect = false;

            if (question.QuestionType == QuestionType.MultipleChoice)
            {
                if (int.TryParse(value, out var selectedOptionId))
                {
                    answerRecord.SelectedOptionId = selectedOptionId;
                    var selected = question.Options.FirstOrDefault(o => o.Id == selectedOptionId);
                    isCorrect = selected?.IsCorrect == true;
                }
            }
            else // True/False
            {
                if (bool.TryParse(value, out var selectedBool))
                {
                    answerRecord.SelectedBoolAnswer = selectedBool;
                    var correct = question.Options.FirstOrDefault(o => o.IsCorrect);
                    var correctBool = correct != null && correct.Text.Equals("True", StringComparison.OrdinalIgnoreCase);
                    isCorrect = selectedBool == correctBool;
                }
            }

            answerRecord.Score = isCorrect ? 1 : 0;
            if (isCorrect) totalCorrect++;

            _context.StudentAnswers.Add(answerRecord);
        }

        studentExam.EndTime = DateTime.Now;
        studentExam.IsCompleted = true;
        studentExam.Score = totalCorrect;

        var max = exam.Questions.Count;
        studentExam.IsPassed = max > 0 && totalCorrect / max >= 0.5;

        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Result), new { studentExamId });
    }

    // GET: /StudentExam/Result/5
    public async Task<IActionResult> Result(int studentExamId)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();

        var studentExam = await _context.StudentExams
            .Include(se => se.Exam)
                .ThenInclude(e => e.Questions)         // <-- include questions for total count
            .Include(se => se.Answers)
                .ThenInclude(sa => sa.Question)
                    .ThenInclude(q => q.Options)
            .FirstOrDefaultAsync(se => se.Id == studentExamId && se.StudentId == user.Id);

        if (studentExam == null) return NotFound();
        if (!studentExam.IsCompleted)
            return RedirectToAction(nameof(Take), new { studentExamId });

        return View(studentExam);
    }

    private async Task<IActionResult> AutoSubmit(StudentExam studentExam)
    {
        if (studentExam.Exam != null)
        {
            foreach (var question in studentExam.Exam.Questions)
            {
                _context.StudentAnswers.Add(new StudentAnswer
                {
                    StudentExamId = studentExam.Id,
                    QuestionId = question.Id,
                    Score = 0
                });
            }
        }

        studentExam.EndTime = DateTime.Now;
        studentExam.IsCompleted = true;
        studentExam.Score = 0;
        studentExam.IsPassed = false;

        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Result), new { studentExamId = studentExam.Id });
    }
}
