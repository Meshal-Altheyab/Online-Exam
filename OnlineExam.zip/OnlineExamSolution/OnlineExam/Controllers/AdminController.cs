using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExam.Models;

namespace OnlineExam.Controllers;

/// <summary>
/// Administrative functions for managing users. Only administrators can
/// access these actions. Currently supports listing users and modifying
/// their role assignments.
/// </summary>
[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly RoleManager<IdentityRole> _roleManager;

    public AdminController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
    {
        _userManager = userManager;
        _roleManager = roleManager;
    }

    // GET: /Admin/Users
    public async Task<IActionResult> Users()
    {
        var users = await _userManager.Users.ToListAsync();
        var model = new List<UserWithRolesViewModel>();
        foreach (var u in users)
        {
            var roles = await _userManager.GetRolesAsync(u);
            model.Add(new UserWithRolesViewModel
            {
                User = u,
                Roles = roles.ToList()
            });
        }
        return View(model);
    }

    // GET: /Admin/EditUser/id
    public async Task<IActionResult> EditUser(string id)
    {
        if (id == null) return NotFound();
        var user = await _userManager.FindByIdAsync(id);
        if (user == null) return NotFound();
        var userRoles = await _userManager.GetRolesAsync(user);
        var allRoles = _roleManager.Roles
            .Where(r => r.Name != null)
            .Select(r => r.Name!)
            .ToList();
        var model = new EditUserRolesViewModel
        {
            UserId = user.Id,
            Email = user.Email!,
            UserName = user.UserName!,
            AvailableRoles = allRoles,
            AssignedRoles = userRoles.ToList()
        };
        return View(model);
    }

    // POST: /Admin/EditUser
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditUser(EditUserRolesViewModel model)
    {
        var user = await _userManager.FindByIdAsync(model.UserId);
        if (user == null) return NotFound();
        var currentRoles = await _userManager.GetRolesAsync(user);
        var selectedRoles = model.SelectedRoles ?? new List<string>();
        // Add roles that are selected and not currently assigned
        var rolesToAdd = selectedRoles.Except(currentRoles).ToList();
        var rolesToRemove = currentRoles.Except(selectedRoles).ToList();
        if (rolesToAdd.Any())
        {
            await _userManager.AddToRolesAsync(user, rolesToAdd);
        }
        if (rolesToRemove.Any())
        {
            await _userManager.RemoveFromRolesAsync(user, rolesToRemove);
        }
        TempData["StatusMessage"] = "User roles updated successfully.";
        return RedirectToAction(nameof(Users));
    }

    /// <summary>
    /// View model representing a user along with their assigned roles.
    /// </summary>
    public class UserWithRolesViewModel
    {
        public ApplicationUser User { get; set; } = new ApplicationUser();
        public List<string> Roles { get; set; } = new List<string>();
    }

    /// <summary>
    /// View model used to edit the roles assigned to a specific user.
    /// </summary>
    public class EditUserRolesViewModel
    {
        public string UserId { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public List<string> AvailableRoles { get; set; } = new List<string>();
        public List<string> AssignedRoles { get; set; } = new List<string>();
        public List<string>? SelectedRoles { get; set; }
    }
}