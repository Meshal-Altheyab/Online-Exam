using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExam.Data;
using OnlineExam.Models;
using OnlineExam.Models.ViewModels;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace OnlineExam.Controllers
{
    [Authorize(Roles = "Educator,Admin")]
    public class QuestionsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public QuestionsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Questions/Index?examId=5
        public async Task<IActionResult> Index(int examId)
        {
            var exam = await _context.Exams.Include(e => e.Creator).FirstOrDefaultAsync(e => e.Id == examId);
            if (exam == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();
            if (!User.IsInRole("Admin") && exam.CreatorId != user.Id) return Forbid();

            var questions = await _context.Questions
                .Where(q => q.ExamId == examId)
                .Include(q => q.Options)
                .ToListAsync();

            ViewBag.Exam = exam;
            return View(questions);
        }

        // GET: Questions/Create?examId=5
        public async Task<IActionResult> Create(int examId)
        {
            var exam = await _context.Exams.FindAsync(examId);
            if (exam == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();
            if (!User.IsInRole("Admin") && exam.CreatorId != user.Id) return Forbid();

            var model = new CreateQuestionViewModel { ExamId = examId, QuestionType = QuestionType.MultipleChoice };
            return View(model);
        }

        // POST: Questions/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateQuestionViewModel model)
        {
            var exam = await _context.Exams.Include(e => e.Creator).FirstOrDefaultAsync(e => e.Id == model.ExamId);
            if (exam == null) return NotFound();
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();
            if (!User.IsInRole("Admin") && exam.CreatorId != user.Id) return Forbid();

            if (!ModelState.IsValid) return View(model);

            var question = new Question
            {
                ExamId = model.ExamId,
                Text = model.Text,
                QuestionType = model.QuestionType
            };

            _context.Questions.Add(question);
            await _context.SaveChangesAsync();

            var optionEntities = new List<Option>();

            if (model.QuestionType == QuestionType.MultipleChoice)
            {
                if (model.Options == null || model.Options.Count < 2)
                {
                    ModelState.AddModelError(string.Empty, "At least two options are required for multiple-choice questions.");
                    return View(model);
                }
                if (model.CorrectOptionIndex < 0 || model.CorrectOptionIndex >= model.Options.Count)
                {
                    ModelState.AddModelError(string.Empty, "Please select a valid correct option index.");
                    return View(model);
                }

                for (int i = 0; i < model.Options.Count; i++)
                {
                    var text = (model.Options[i] ?? string.Empty).Trim();
                    if (string.IsNullOrWhiteSpace(text)) continue;

                    optionEntities.Add(new Option
                    {
                        QuestionId = question.Id,
                        Text = text,
                        IsCorrect = (i == model.CorrectOptionIndex)
                    });
                }
            }
            else
            {
                optionEntities.Add(new Option { QuestionId = question.Id, Text = "True", IsCorrect = model.CorrectBoolAnswer });
                optionEntities.Add(new Option { QuestionId = question.Id, Text = "False", IsCorrect = !model.CorrectBoolAnswer });
            }

            _context.Options.AddRange(optionEntities);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index), new { examId = model.ExamId });
        }

        // GET: Questions/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var question = await _context.Questions
                .Include(q => q.Options)
                .Include(q => q.Exam)
                .FirstOrDefaultAsync(q => q.Id == id);

            if (question == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();
            if (!User.IsInRole("Admin") && question.Exam?.CreatorId != user.Id) return Forbid();

            var model = new EditQuestionViewModel
            {
                Id = question.Id,
                ExamId = question.ExamId,
                Text = question.Text,
                QuestionType = question.QuestionType
            };

            if (question.QuestionType == QuestionType.MultipleChoice)
            {
                model.Options = question.Options.Select(o => o.Text).ToList();
                model.CorrectOptionIndex = question.Options.ToList().FindIndex(o => o.IsCorrect);
            }
            else
            {
                var correct = question.Options.FirstOrDefault(o => o.IsCorrect);
                model.CorrectBoolAnswer = correct != null && correct.Text.Equals("True", System.StringComparison.OrdinalIgnoreCase);
            }

            return View(model);
        }

        // POST: Questions/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, EditQuestionViewModel model)
        {
            if (id != model.Id) return NotFound();

            var question = await _context.Questions
                .Include(q => q.Options)
                .Include(q => q.Exam)
                .FirstOrDefaultAsync(q => q.Id == id);
            if (question == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();
            if (!User.IsInRole("Admin") && question.Exam?.CreatorId != user.Id) return Forbid();

            if (!ModelState.IsValid) return View(model);

            question.Text = model.Text;
            question.QuestionType = model.QuestionType;

            if (question.Options?.Count > 0)
            {
                _context.Options.RemoveRange(question.Options);
                await _context.SaveChangesAsync();
            }

            var newOptions = new List<Option>();

            if (model.QuestionType == QuestionType.MultipleChoice)
            {
                if (model.Options == null || model.Options.Count < 2 ||
                    model.CorrectOptionIndex < 0 || model.CorrectOptionIndex >= model.Options.Count)
                {
                    ModelState.AddModelError(string.Empty, "Please provide valid options and select one correct answer.");
                    return View(model);
                }

                for (int i = 0; i < model.Options.Count; i++)
                {
                    var text = (model.Options[i] ?? string.Empty).Trim();
                    if (string.IsNullOrWhiteSpace(text)) continue;

                    newOptions.Add(new Option
                    {
                        QuestionId = question.Id,
                        Text = text,
                        IsCorrect = (i == model.CorrectOptionIndex)
                    });
                }
            }
            else
            {
                newOptions.Add(new Option { QuestionId = question.Id, Text = "True", IsCorrect = model.CorrectBoolAnswer });
                newOptions.Add(new Option { QuestionId = question.Id, Text = "False", IsCorrect = !model.CorrectBoolAnswer });
            }

            _context.Options.AddRange(newOptions);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index), new { examId = question.ExamId });
        }

        // GET: Questions/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var question = await _context.Questions
                .Include(q => q.Options)
                .Include(q => q.Exam)
                .FirstOrDefaultAsync(q => q.Id == id);

            if (question == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();
            if (!User.IsInRole("Admin") && question.Exam?.CreatorId != user.Id) return Forbid();

            return View(question);
        }

        // POST: Questions/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var question = await _context.Questions
                .Include(q => q.Options)
                .Include(q => q.Exam)
                .FirstOrDefaultAsync(q => q.Id == id);

            if (question == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();
            if (!User.IsInRole("Admin") && question.Exam?.CreatorId != user.Id) return Forbid();

            if (question.Options != null && question.Options.Count > 0)
            {
                _context.Options.RemoveRange(question.Options);
            }

            _context.Questions.Remove(question);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index), new { examId = question.ExamId });
        }
    }
}
