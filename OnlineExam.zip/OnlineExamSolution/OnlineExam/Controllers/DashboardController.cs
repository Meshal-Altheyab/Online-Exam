using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExam.Data;
using OnlineExam.Models;

namespace OnlineExam.Controllers;

/// <summary>
/// Displays analytics dashboards tailored to each role. Administrators
/// see system‑wide statistics such as user counts, exam completion rates
/// and rankings by university. Educators see aggregated results for
/// their exams, while students see their own performance summary.
/// </summary>
[Authorize]
public class DashboardController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public DashboardController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // GET: /Dashboard
    public async Task<IActionResult> Index()
    {
        if (User.IsInRole("Admin"))
        {
            return await Admin();
        }
        else if (User.IsInRole("Educator"))
        {
            return await Educator();
        }
        else
        {
            return await Student();
        }
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Admin()
    {
        // User counts by role
        var totalUsers = await _context.Users.CountAsync();
        var admins = await _userManager.GetUsersInRoleAsync("Admin");
        var educators = await _userManager.GetUsersInRoleAsync("Educator");
        var students = await _userManager.GetUsersInRoleAsync("Student");

        ViewBag.UserCounts = new
        {
            Total = totalUsers,
            Admins = admins.Count,
            Educators = educators.Count,
            Students = students.Count
        };

        // Exam completion rates: for each exam count completed StudentExams
        var examRates = await _context.Exams
            .Select(e => new
            {
                e.Title,
                TotalQuestions = e.Questions.Count,
                TotalStarted = _context.StudentExams.Count(se => se.ExamId == e.Id),
                Completed = _context.StudentExams.Count(se => se.ExamId == e.Id && se.IsCompleted),
                Passed = _context.StudentExams.Count(se => se.ExamId == e.Id && se.IsPassed)
            })
            .ToListAsync();
        ViewBag.ExamRates = examRates;

        // Ranking by university: average score per university
        var universityRank = await _context.StudentExams
            .Where(se => se.IsCompleted)
            .GroupBy(se => se.Student!.University)
            .Select(g => new
            {
                University = g.Key ?? "Unknown",
                AverageScore = g.Average(se => se.Score),
                TotalStudents = g.Count()
            })
            .OrderByDescending(g => g.AverageScore)
            .ToListAsync();
        ViewBag.UniversityRank = universityRank;

        // Totals for pass/fail across the platform
        ViewBag.PlatformTotals = new
        {
            TotalExams = await _context.Exams.CountAsync(),
            TotalAttempts = await _context.StudentExams.CountAsync(),
            TotalCompleted = await _context.StudentExams.CountAsync(se => se.IsCompleted),
            TotalPassed = await _context.StudentExams.CountAsync(se => se.IsPassed)
        };

        return View("Admin");
    }

    [Authorize(Roles = "Educator")]
    public async Task<IActionResult> Educator()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        // Exams created by educator with aggregated results
        var educatorExamStats = await _context.Exams
            .Where(e => e.CreatorId == user.Id)
            .Select(e => new
            {
                ExamTitle = e.Title,
                TotalQuestions = e.Questions.Count,
                TotalStudents = _context.StudentExams.Count(se => se.ExamId == e.Id),
                Started = _context.StudentExams.Count(se => se.ExamId == e.Id && !se.IsCompleted),
                Completed = _context.StudentExams.Count(se => se.ExamId == e.Id && se.IsCompleted),
                PassedStudents = _context.StudentExams.Count(se => se.ExamId == e.Id && se.IsPassed),
                FailedStudents = _context.StudentExams.Count(se => se.ExamId == e.Id && se.IsCompleted && !se.IsPassed)
            })
            .ToListAsync();
        ViewBag.EducatorExamStats = educatorExamStats;
        return View("Educator");
    }

    [Authorize(Roles = "Student")]
    public async Task<IActionResult> Student()
    {
        var user = await _userManager.GetUserAsync(User);
        if (user == null) return Challenge();
        var examsTaken = await _context.StudentExams
            .Where(se => se.StudentId == user.Id)
            .Include(se => se.Exam)
            .ToListAsync();
        ViewBag.StudentExams = examsTaken;
        return View("Student");
    }
}