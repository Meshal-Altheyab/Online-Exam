using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.Extensions.Options;

namespace OnlineExam.Services;

public class SmtpOptions
{
    public string Host { get; set; } = string.Empty;
    public int Port { get; set; } = 587;
    public bool EnableSsl { get; set; } = true;
    public string User { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string From { get; set; } = "no-reply@example.com";
}

public class SmtpEmailSender : IEmailSender
{
    private readonly SmtpOptions _options;

    public SmtpEmailSender(IOptions<SmtpOptions> options)
    {
        _options = options.Value;
    }

    public async Task SendEmailAsync(string email, string subject, string htmlMessage)
    {
        using var client = new SmtpClient(_options.Host, _options.Port)
        {
            EnableSsl = _options.EnableSsl,
            Credentials = new NetworkCredential(_options.User, _options.Password)
        };

        var from = new MailAddress(ParseAddress(_options.From).email, ParseAddress(_options.From).name);
        var to = new MailAddress(email);
        using var message = new MailMessage(from, to)
        {
            Subject = subject,
            Body = htmlMessage,
            IsBodyHtml = true
        };

        await client.SendMailAsync(message);
    }

    private static (string name, string email) ParseAddress(string input)
    {
        // Supports formats like "Display Name <email@domain>" or just "email@domain"
        var lt = input.IndexOf('<');
        var gt = input.IndexOf('>');
        if (lt >= 0 && gt > lt)
        {
            var name = input.Substring(0, lt).Trim();
            var email = input.Substring(lt + 1, gt - lt - 1).Trim();
            return (name, email);
        }
        return (input, input);
    }
} 