using System.ComponentModel.DataAnnotations;

namespace OnlineExam.Models
{
    public class Option
    {
        public int Id { get; set; }

        [Required]
        public int QuestionId { get; set; }
        public Question Question { get; set; } = default!;

        [Required, StringLength(500)]
        public string Text { get; set; } = string.Empty;

        public bool IsCorrect { get; set; }
    }
}
