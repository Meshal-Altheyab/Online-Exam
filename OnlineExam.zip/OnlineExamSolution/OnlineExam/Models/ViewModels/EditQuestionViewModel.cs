using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OnlineExam.Models.ViewModels
{
    public class EditQuestionViewModel
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public int ExamId { get; set; }

        [Required, StringLength(1000)]
        public string Text { get; set; } = string.Empty;

        [Required]
        public QuestionType QuestionType { get; set; }

        // For MultipleChoice
        public List<string> Options { get; set; } = new();
        public int CorrectOptionIndex { get; set; } = 0;

        // For True/False
        public bool CorrectBoolAnswer { get; set; } = true;
    }
}
