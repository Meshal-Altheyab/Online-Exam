namespace OnlineExam.Models
{
    public enum QuestionType
    {
        MultipleChoice = 0,
        TrueFalse = 1
    }
}
