using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace OnlineExam.Models;

/// <summary>
/// Extends the ASP.NET Core IdentityUser with additional properties used
/// throughout the online exam platform. These properties are persisted
/// alongside the built-in Identity fields.
/// </summary>
public class ApplicationUser : IdentityUser
{
    /// <summary>
    /// Gets or sets the display name for the user. This name is
    /// shown in various parts of the UI instead of the username.
    /// </summary>
    [MaxLength(100)]
    public string? Name { get; set; }

    /// <summary>
    /// Gets or sets the university affiliation of the user. Used in
    /// analytics to group users by institution for ranking.
    /// </summary>
    [MaxLength(100)]
    public string? University { get; set; }

    /// <summary>
    /// Gets or sets the relative path to the user's profile image stored
    /// under wwwroot/images/profiles. Only image files are allowed and
    /// upload limits are enforced in the Profile controller.
    /// </summary>
    [MaxLength(200)]
    public string? ProfileImagePath { get; set; }
}