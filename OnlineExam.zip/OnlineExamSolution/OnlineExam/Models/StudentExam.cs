﻿using System;
using System.Collections.Generic;

namespace OnlineExam.Models
{
    public class StudentExam
    {
        public int Id { get; set; }

        public int ExamId { get; set; }
        public Exam Exam { get; set; } = default!;

        public string StudentId { get; set; } = default!;
        public ApplicationUser Student { get; set; } = default!;

        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        public bool IsCompleted { get; set; }
        public double Score { get; set; }
        public bool IsPassed { get; set; }

        public ICollection<StudentAnswer> Answers { get; set; } = new List<StudentAnswer>();
    }
}
