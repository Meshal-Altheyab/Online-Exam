﻿namespace OnlineExam.Models
{
    public class StudentAnswer
    {
        public int Id { get; set; }

        public int StudentExamId { get; set; }
        public StudentExam StudentExam { get; set; } = default!;

        public int QuestionId { get; set; }
        public Question Question { get; set; } = default!;

        public int? SelectedOptionId { get; set; }
        public Option? SelectedOption { get; set; }

        public bool? SelectedBoolAnswer { get; set; }

        public double Score { get; set; }
    }
}
