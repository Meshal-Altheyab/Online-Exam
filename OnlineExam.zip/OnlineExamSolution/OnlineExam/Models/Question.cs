using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OnlineExam.Models
{
    public class Question
    {
        public int Id { get; set; }

        [Required]
        public int ExamId { get; set; }
        public Exam Exam { get; set; } = default!;

        [Required, StringLength(1000)]
        public string Text { get; set; } = string.Empty;

        [Required]
        public QuestionType QuestionType { get; set; }

        public ICollection<Option> Options { get; set; } = new List<Option>();
    }
}
