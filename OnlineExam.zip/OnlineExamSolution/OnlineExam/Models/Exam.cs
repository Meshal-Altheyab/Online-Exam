using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineExam.Models
{
    public class Exam
    {
        public int Id { get; set; }

        [Required, MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [MaxLength(1000)]
        public string? Description { get; set; }

        [MaxLength(100)]
        public string? Subject { get; set; }

        [MaxLength(50)]
        public string? Difficulty { get; set; }

        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        [Range(1, 600)]
        public int DurationMinutes { get; set; }

        public string? CreatorId { get; set; }
        [ForeignKey(nameof(CreatorId))]
        public ApplicationUser? Creator { get; set; }

        public ICollection<Question> Questions { get; set; } = new List<Question>();
    }
}
