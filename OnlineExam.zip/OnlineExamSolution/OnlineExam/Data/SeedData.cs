using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using OnlineExam.Models;

namespace OnlineExam.Data;

/// <summary>
/// Seeds default roles and an administrator user into the database on
/// application startup. This method is invoked from Program.cs after the
/// database is migrated.
/// </summary>
public static class SeedData
{
    private static readonly string[] Roles = new[] { "Admin", "Educator", "Student" };

    /// <summary>
    /// Ensures that default roles are created and a default administrator
    /// account exists. If the admin user doesn't exist, one is created with
    /// a known password. For security reasons you should change this
    /// password after first login.
    /// </summary>
    /// <param name="services">Service provider used to resolve Identity managers.</param>
    public static async Task InitializeAsync(IServiceProvider services)
    {
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();

        // Ensure roles exist
        foreach (var roleName in Roles)
        {
            if (!await roleManager.RoleExistsAsync(roleName))
            {
                await roleManager.CreateAsync(new IdentityRole(roleName));
            }
        }

        // Create the administrator user if it does not already exist
        const string adminEmail = "admin@onlineexam.com";
        const string adminPassword = "Admin@123";

        var adminUser = await userManager.FindByEmailAsync(adminEmail);
        if (adminUser == null)
        {
            adminUser = new ApplicationUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                Name = "System Administrator",
                EmailConfirmed = true
            };
            var result = await userManager.CreateAsync(adminUser, adminPassword);
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }
        }
        else if (!adminUser.EmailConfirmed)
        {
            adminUser.EmailConfirmed = true;
            await userManager.UpdateAsync(adminUser);
        }

        // Create a default educator account for quick testing
        const string educatorEmail = "educator@onlineexam.com";
        const string educatorPassword = "Educator@123";
        var educatorUser = await userManager.FindByEmailAsync(educatorEmail);
        if (educatorUser == null)
        {
            educatorUser = new ApplicationUser
            {
                UserName = educatorEmail,
                Email = educatorEmail,
                Name = "Demo Educator",
                University = "Ejada University",
                EmailConfirmed = true
            };
            var result = await userManager.CreateAsync(educatorUser, educatorPassword);
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(educatorUser, "Educator");
            }
        }

        // Create a default student account for quick testing
        const string studentEmail = "student@onlineexam.com";
        const string studentPassword = "Student@123";
        var studentUser = await userManager.FindByEmailAsync(studentEmail);
        if (studentUser == null)
        {
            studentUser = new ApplicationUser
            {
                UserName = studentEmail,
                Email = studentEmail,
                Name = "Demo Student",
                University = "Ejada University",
                EmailConfirmed = true
            };
            var result = await userManager.CreateAsync(studentUser, studentPassword);
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(studentUser, "Student");
            }
        }
    }
}