﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using OnlineExam.Models;

namespace OnlineExam.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Exam> Exams => Set<Exam>();
        public DbSet<Question> Questions => Set<Question>();
        public DbSet<Option> Options => Set<Option>();
        public DbSet<StudentExam> StudentExams => Set<StudentExam>();
        public DbSet<StudentAnswer> StudentAnswers => Set<StudentAnswer>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Exam → Questions (keep cascade)
            modelBuilder.Entity<Question>()
                .HasOne(q => q.Exam)
                .WithMany(e => e.Questions)
                .HasForeignKey(q => q.ExamId)
                .OnDelete(DeleteBehavior.Cascade);

            // Question → Options (keep cascade)
            modelBuilder.Entity<Option>()
                .HasOne(o => o.Question)
                .WithMany(q => q.Options)
                .HasForeignKey(o => o.QuestionId)
                .OnDelete(DeleteBehavior.Cascade);

            // StudentExam → Exam (BREAK cascade)
            modelBuilder.Entity<StudentExam>()
                .HasOne(se => se.Exam)
                .WithMany()
                .HasForeignKey(se => se.ExamId)
                .OnDelete(DeleteBehavior.Restrict);   // or .NoAction()

            // StudentAnswer → StudentExam (keep cascade)
            modelBuilder.Entity<StudentAnswer>()
                .HasOne(a => a.StudentExam)
                .WithMany(se => se.Answers)
                .HasForeignKey(a => a.StudentExamId)
                .OnDelete(DeleteBehavior.Cascade);

            // StudentAnswer → Question (NO ACTION)
            modelBuilder.Entity<StudentAnswer>()
                .HasOne(a => a.Question)
                .WithMany()
                .HasForeignKey(a => a.QuestionId)
                .OnDelete(DeleteBehavior.NoAction);

            // StudentAnswer → SelectedOption (SET NULL)
            modelBuilder.Entity<StudentAnswer>()
                .HasOne(a => a.SelectedOption)
                .WithMany()
                .HasForeignKey(a => a.SelectedOptionId)
                .OnDelete(DeleteBehavior.SetNull);

            // Never cascade delete users
            modelBuilder.Entity<StudentExam>()
                .HasOne(se => se.Student)
                .WithMany()
                .HasForeignKey(se => se.StudentId)
                .OnDelete(DeleteBehavior.NoAction);

        }

    }
}
