using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OnlineExam.Data;
using OnlineExam.Models;
using Microsoft.AspNetCore.Identity.UI.Services;
using OnlineExam.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Configure the connection string for SQL Server. The default connection
// string is defined in appsettings.json and can be overridden via
// user-secrets or environment variables.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

// Add ASP.NET Core Identity services. We use IdentityRole for role
// management and ApplicationUser for custom user properties. The default
// identity UI is added via AddDefaultUI which brings in the Razor pages
// for login, register, etc.
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
    {
        // In production, require confirmed accounts. In development, allow login without confirmation
        options.SignIn.RequireConfirmedAccount = !builder.Environment.IsDevelopment();
        options.Password.RequireDigit = true;
        options.Password.RequireLowercase = true;
        options.Password.RequireUppercase = true;
        options.Password.RequireNonAlphanumeric = false;
        options.Password.RequiredLength = 6;
    })
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders()
    .AddDefaultUI();

// Email sender for email confirmation and password recovery
builder.Services.Configure<SmtpOptions>(builder.Configuration.GetSection("Smtp"));
builder.Services.AddTransient<IEmailSender, SmtpEmailSender>();

builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

var app = builder.Build();

// Initialize the database and seed default roles/users. This should be
// executed on startup to ensure roles are created before any requests
// requiring role authorization are processed.
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var dbContext = services.GetRequiredService<ApplicationDbContext>();
    await dbContext.Database.MigrateAsync();

    // Seed roles and an initial administrator account
    await SeedData.InitializeAsync(services);
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

// Set up conventional routing for MVC controllers
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Map Razor Pages for Identity UI
app.MapRazorPages();

await app.RunAsync();

// This method is required for integration tests and EF design-time services
public partial class Program
{
    protected Program() { }
}